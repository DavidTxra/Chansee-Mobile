import React from "react";
import { Text, View, FlatList } from "react-native";
import Buttons from "./Components/Buttons";
import DisplayImage from "./Components/DisplayImage";

export default class App extends React.Component {
  render() {
    return (
      <View>
        <Text>Voila</Text>
        <Buttons />
        <DisplayImage />
      </View>
    );
  }
}
